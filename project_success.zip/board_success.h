#include <fstream>

#include "page.h"

#include <iostream>
using std::cerr ;

using std::endl;
using std::ofstream;

class Board {
    public:
        Board(int num_jobs, int width, int height, ofstream& output_stream);
        ~Board(); //destructor

        void print_board();
        void print_job(int job_idx, char job_type, int id);

        Page find_page(int target) ; // find page using id
        int highest(int* ptr) ; // return index of highest page id
        void above_sorted(Page) ;
        bool in_array(int*, int) ;
        int lowest(int* ptr) ;
        void delete_all(int) ;
        void print_above(int*) ;
        void merge(int*,int,int,int) ;
        void sort_ptr(int*,int,int) ;
        void weak_insert(int x, int y, int width, int height, int id, char content) ;

        //job functions
        void insert_page(int x, int y, int width, int height, int id, char content);
        void delete_page(int id);
        void modify_content(int id, char content);
        void modify_position(int id, int x, int y);

    private:
        int num_jobs, width, height; 
        ofstream& output; 
        int **board; // pointer(board) of pointer(current pages)
        Page *pages ; // dynamic array for log
        int p_index ;
        Page null_page ; // default page
};

Board::Board(int num_jobs, int width, int height, ofstream& output_stream): output(output_stream) {
    this->width = width; // derefernce+attribute
    this->height = height;
    this->num_jobs = num_jobs;

    board = new int*[width*height]; 

    for (int i = 0; i < width*height; i++) { 
        board[i] = new int[num_jobs+1] ; // allocate memory to board, first element should remain -1
        for (int j=0; j<=num_jobs; j++)
        {
            board[i][j] = -1 ; // initialize each spot
        }
    }

    pages = new Page[num_jobs+1] ; // the first element should remain null
    p_index = 0 ;
    null_page = Page(0,0,width,height,-1,' ') ; // declare null page
    
    null_page.init_above(num_jobs) ;
    for (int i=0; i<num_jobs; i++)
    {
        null_page.set_above(null_page.get_above(), i, -1) ;
    }

    for (int i=0; i<=num_jobs; i++)
    {
        pages[i] = null_page ; // initialize log
    }
}

Board::~Board() {
    for (int i=0; i<=num_jobs; i++) // destructor
    {
        delete pages[i].get_above() ;
        pages[i].setnull() ;
    }

    for (int i=0; i < width*height-1; i++) { 
        delete board[i] ;
        board[i] = nullptr ;
    }
    delete board;
    board = nullptr ;

    delete pages ;
    pages = nullptr ;
}

Page::Page(){} // default constructor for NEW Page

Page::Page(int x, int y, int width, int height, int id, char content) // constructor
{
    this->x = x ;
    this->y = y ;
    this->width = width ;
    this->height = height ;
    this->id = id ;
    this->content = content ;
}

bool Board::in_array(int *arr, int target) 
{
    for (int i=0; i<num_jobs; i++)
    {
        if (arr[i] == target) {return true ;}
    }
    return false ;
}

void Board::above_sorted(Page target) // make SORTED id list of pages above
{
// PROBLEM: overlapping above
    int *abv = target.get_above() ;
    for (int i=0; i<num_jobs; i++)
    {
        target.set_above(abv, i, -1) ; // initialize
    }

    int start = target.get_x() + width*(target.get_y()) ;
    for (int i=0; i<target.get_height(); i++)
    {
        for (int j=0; j<target.get_width(); j++)
        {
            int next = 0 ;
            int *spot = board[start + i*width + j] ;
            for (int k=1; k<=highest(spot); k++)
            {
                if (spot[k] == target.get_id()) // find above page
                {
                    next = k+1 ;
                    break ;
                }
            }

            if ((spot[next]!=-1) && !(in_array(abv, spot[next]))) // append
            {
                target.set_above(abv, highest(abv)+1, spot[next]) ;
            }
        }
    }
    
    // abv = {-1, a, b, c, ..., -1}
    // solve double deletion
    if (abv[1] != -1) // if abv exist
    {
        int over_idx[num_jobs] = {0, } ; // save index of overlapping id
        int idx = 0 ;

        for (int i=1; i<=highest(abv); i++)
        {
            Page a_page = find_page(abv[i]) ;
            above_sorted(a_page) ;
            int*a_abv = a_page.get_above() ;

            for (int j=1; j<=highest(abv); j++)
            {
                for (int k=0; k<num_jobs; k++)
                {
                    if ((abv[j] == a_abv[k]) && (abv[j] > abv[i])) // overlap and bigger
                    {
                        over_idx[idx] = j ; // save index
                        idx += 1 ;
                    }
                }
            }
        }
        // over_idx = {2, 4, 0, ..., 0}
        int i=0 ;
        while (over_idx[i] != 0) // while overlap&bigger exist
        {
            target.set_above(abv, over_idx[i], -1) ;
            i += 1 ;
        }
        // abv = {-1, a, -1, c, -1, ..., -1}   

    }

    sort_ptr(abv,0,num_jobs-1) ;
    // abv = {-1,...,-1, a, c}
}

int Board::highest(int* ptr)
{
    int i=0 ;
    while(ptr[i+1] != -1)
    {
        i+=1 ;
    }
    return i ; // index
}

int Board::lowest(int* ptr) // used for array size num_jobs
{
    int i=num_jobs-1 ;
    while(ptr[i-1] != -1)
    {
        i-=1 ;
    }
    return i ; // index
}

void Board::print_board()
{ // print board element
    int h, w;
    for (w = 0; w < width+2; w++) {output << "- ";}
    output << endl;
    
    for (h = 0; h < height; h++)
    {
        output << "| ";
    
        for (w = 0; w < width; w++)
        {
            int *spot = board[h*width + w] ;
            output << find_page(spot[highest(spot)]).get_content() << " "; // print content of page
        }
    
        output << "| " << endl;
    }

    for (w = 0; w < width+2; w++) {output << "- ";}
    output << endl;
}

void Board::print_job(int job_idx, char job_type, int id) { // show job
    output << ">> (" << job_idx <<") ";
    switch(job_type) {
        
        case 'i':
            output << "Insert ";
            break;
        case 'd':
            output << "Delete ";
            break;
        case 'm':
            output << "Modify ";
            break;
    }

    output << id << endl;
}

Page Board::find_page(int target) // return page of particular id
{
    for (int i=1; i<=num_jobs; i++)
    {
        if (pages[i].get_id() == target)
        {
            return pages[i] ;
        }
    }
    return null_page ;
}

void Board::delete_all(int id) // recursive deletion
{
    Page target = find_page(id) ; // target page
    above_sorted(target) ;
    int *abv = target.get_above() ;

    if (abv[num_jobs-1] != -1) // when abv exist
    {
        for (int i=lowest(abv); i<num_jobs; i++) // delete smallest id first
        {
            delete_all(abv[i]) ;
        }
    }

    int start = target.get_x() + width*target.get_y() ;
    for (int i=0; i<target.get_height(); i++)
    {
        for (int j=0; j<target.get_width(); j++)
        {
            int *spot = board[start + i*width + j] ;
            spot[highest(spot)] = -1 ; // delete id from each spot
        }
    }

    print_board() ;
}

void Board::print_above(int *abv)
{
    if (abv[num_jobs-1] != -1) // when abv exist
    {
        for (int i=num_jobs-1; i>=lowest(abv); i--)
        {
            int id = abv[i] ;
            Page i_page = find_page(id) ;
            int x = i_page.get_x() ;
            int y = i_page.get_y() ;
            int width = i_page.get_width() ;
            int height = i_page.get_height() ;
            char content = i_page.get_content() ;

            weak_insert(x,y,width,height,id,content) ; // include print

            print_above(i_page.get_above()) ; // recursive re-print
        }
    }
}

void Board::insert_page(int x, int y, int width, int height, int id, char content)
{
    Page page = Page(x,y,width,height,id,content) ;
    page.init_above(num_jobs) ;
    for (int i=0; i<num_jobs; i++)
    {
        page.set_above(page.get_above(), i, -1) ;
    }

    p_index += 1 ; // only for NEW page
    pages[p_index] = page ; // save page in log

    int start = x + (this->width)*y ;
    for (int i=0; i<height; i++)
    {
        for (int j=0; j<width; j++)
        {
            int *spot = board[start + i*(this->width) + j] ;
            spot[highest(spot)+1] = id ; // append id to ptrptr
        }
    }
    print_board() ;
}


void Board::weak_insert(int x, int y, int width, int height, int id, char content)
{
    int start = x + (this->width)*y ;
    for (int i=0; i<height; i++)
    {
        for (int j=0; j<width; j++)
        {
            int *spot = board[start + i*(this->width) + j] ;
            spot[highest(spot)+1] = id ; // append id to ptrptr
        }
    }
    print_board() ;
}

void Board::delete_page(int id) { // PROBLEM: deletion unordered
    Page target = find_page(id) ; // target page
    above_sorted(target) ;
    int *abv = target.get_above() ; // save above list
    
    delete_all(id) ;

    print_above(abv) ; // re-print pages above
}

void Board::modify_content(int id, char content)
{
    Page target = find_page(id) ; // target page
    above_sorted(target) ;
    int *abv = target.get_above() ; // save above list

    int x = target.get_x() ;
    int y = target.get_y() ;
    int width = target.get_width() ;
    int height = target.get_height() ;

    delete_all(id) ;

    target.set_content(content) ; // modify content

    for (int i=0; i<=num_jobs; i++)
    {
        if (pages[i].get_id() == id)
        {
            pages[i] = target ; // update pages
            break ;
        }
    }

    weak_insert(x,y,width,height,id,content) ;

    print_above(abv) ;
}

void Board::modify_position(int id, int x, int y) {
    Page target = find_page(id) ; // target page
    above_sorted(target) ;
    int *abv = target.get_above() ; // save above list
    
    int width = target.get_width() ;
    int height = target.get_height() ;
    char content = target.get_content() ;

    delete_all(id) ;

    target.set_position(x,y) ; // modify position

    for (int i=0; i<=num_jobs; i++)
    {
        if (pages[i].get_id() == id)
        {
            pages[i] = target ; // update pages
            break ;
        }
    }

    weak_insert(x,y,width,height,id,content) ;

    print_above(abv) ;
}

// merge sort of pointer
void Board::merge(int* arr, int left, int mid, int right) {
    int i, j, k;
    int n1 = mid - left + 1;
    int n2 = right - mid;

    int* L = new int[n1];
    int* R = new int[n2];

    for (i = 0; i < n1; i++)
        L[i] = arr[left + i];
    for (j = 0; j < n2; j++)
        R[j] = arr[mid + 1 + j];

    i = 0;
    j = 0;
    k = left;
    while (i < n1 && j < n2) {
        if (L[i] <= R[j]) {
            arr[k] = L[i];
            i++;
        }
        else {
            arr[k] = R[j];
            j++;
        }
        k++;
    }

    while (i < n1) {
        arr[k] = L[i];
        i++;
        k++;
    }
    while (j < n2) {
        arr[k] = R[j];
        j++;
        k++;
    }

    // free memory used by temporary arrays
    delete[] L;
    L = nullptr ;
    delete[] R;
    R = nullptr ;
}

void Board::sort_ptr(int* arr, int left, int right) {
    if (left < right) {
        int mid = left + (right - left) / 2;

        // recursively sort the left and right halves of arr
        sort_ptr(arr, left, mid);
        sort_ptr(arr, mid + 1, right);

        // merge the sorted halves
        merge(arr, left, mid, right);
    }
}
