class Page {
    public:
        Page() ;
        Page (int x, int y, int width, int height, int id, char content) ; // constructor
        int get_id () ; // accessor(getter)
        int get_x() ;
        int get_y() ;
        int get_width() ;
        int get_height() ;
        int get_content() ;
        int* get_above() ;
        void set_above(int*,int,int) ; // mutator(setter)
        void set_content(char) ;
        void set_position(int, int) ;
        void setnull() ;
        void init_above(int) ;

    private:
        int x, y; // position of the page on the board
        int width, height; // width and height of the page 
        int id; // unique id for each page
        char content;
        int *above ; // save id of pages above
};

int Page::get_id(){return id ;}
int Page::get_x(){return x ;}
int Page::get_y(){return y ;}
int Page::get_width(){return width ;}
int Page::get_height(){return height ;}
int Page::get_content(){return content ;}
int* Page::get_above(){return above ;}
void Page::set_above(int* arr, int index, int value){arr[index] = value ;}
void Page::set_content(char new_con){content = new_con ;}
void Page::set_position(int new_x, int new_y){x = new_x ; y=new_y ;}
void Page::setnull(){above = nullptr ;}
void Page::init_above(int n){above = new int[n] ;}
