#include <fstream>
#include <algorithm>

#include "page.h"

using std::endl;
using std::ofstream;

class Board {
    public:
        Board(int num_jobs, int width, int height, ofstream& output_stream);
        ~Board(); //destructor

        void print_board();
        void print_job(int job_idx, char job_type, int id);

        // bool overlap(Page, Page) ; // judge overlapping
        Page find_page(int target) ; // find page using id
        int highest(int* ptr) ; // return index of highest page id
        void above_sorted(Page) ;
        bool in_array(int*, int) ;
        int lowest(int* ptr) ;

        //job functions
        void insert_page(int x, int y, int width, int height, int id, int content);
        void delete_page(int id);
        void modify_content(int id, char content);
        void modify_position(int id, int x, int y);

    private:
        int num_jobs, width, height; 
        ofstream& output; 
        int **board; // pointer(board) of pointer(current pages)
        Page *pages ; // dynamic array for log
        int p_index ;
        Page null_page ; // default page
};


Board::Board(int num_jobs, int width, int height, ofstream& output_stream): output(output_stream) {
    this->width = width; // derefernce+attribute
    this->height = height;
    this->num_jobs = num_jobs;

    board = new int*[width*height]; 

    for (int i = 0; i < width*height-1; i++) { 
        board[i] = new int[num_jobs] ; // allocate memory to board
        for (int j=0; j<num_jobs; j++)
        {
            board[i][j] = -1 ; // initialize each spot
        }
    }

    pages = new Page[num_jobs] ;
    p_index = 0 ;
    null_page = Page(0,0,width,height,-1,' ') ; // declare null page
    for (int i=0; i<num_jobs; i++)
    {
        pages[i] = null_page ; // initialize log
    }
}

Board::~Board() {
    for (int i=0; i < width*height-1; i++) { 
        delete [] board[i] ;
    }
    delete [] board;
    
}

Page::Page (int x, int y, int width, int height, int id, char content) // constructor
{
    this->x = x ;
    this->y = y ;
    this->width = width ;
    this->height = height ;
    this->id = id ;
    this->content = content ;
    above = new int[num_jobs]
    for (int i=0; i<num_jobs; i++)
    {
        above[i] = -1 ;
    }
}

bool Board::in_array(int *arr, int target)
{
    for (int i=0; i<=highest(arr); i++)
    {
        if (arr[i] == target) {return true ;}
    }
    return false ;
}

void Board::above_sorted(Page target) // make SORTED id list of pages above
{
    int *abv = target.get_above() ;
    for (int i=0; i<num_jobs; i++)
    {
        target.set_above(abv, i, -1) ; // initialize
    }

    int start = target.get_x() + width*(target.get_y()) ;
    for (int i=0; i<target.get_height(), i++)
    {
        for (int j=0; j<target.get_width(), j++)
        {
            int next = 0 ;
            int *spot = board[start + i*width + j] ;
            for (int k=0; k<=highest(spot); k++)
            {
                if (spot[k] == target.get_id()) // find above page
                {
                    next = k+1 ;
                    break ;
                }
            }

            if ((spot[next]!=-1) && !(in_array(abv,spot[next]))) // append
            {
                target.set_above(abv, highest(abv)+1, spot[next]) ;
            }
        }
    }
    sort(abv) ;
}

int Board::highest(int* ptr)
{
    int i=0 ;
    while(ptr[i+1] != -1)
    {
        i+=1 ;
    }
    return i ;
}

int Board::lowest(int* ptr)
{
    int i=num_jobs-1 ;
    while(ptr[i-1] != -1)
    {
        i-=1 ;
    }
    return i ;
}

void Board::print_board() { // print board element
    int h, w;
    for (w = 0; w < width+2; w++) output << "- ";
    output << endl;
    
    for (h = 0; h < height; h++) {
        output << "| ";
        for (w = 0; w < width; w++) {
            int *spot = board[h*width + w]
            output << find_page(spot[highest(spot)]).get_content << " "; // print content of page
        }
        output << "| " << endl;
    }

    for (w = 0; w < width+2; w++) output << "- ";
    output << endl;
}

void Board::print_job(int job_idx, char job_type, int id) { // show job
    switch(job_type) {
        
        case 'i':
            output << "Insert ";
            break;
        case 'd':
            output << "Delete ";
            break;
        case 'm':
            output << "Modify ";
            break;
    }

    output << id << endl;
}

Page Board::find_page(int target) // return page of particular id
{
    for (int i=num_jobs; i>0; i--)
    {
        if (pages[i-1].get_id() == target)
        {
            return pages[i-1] ;
        }
    }
}

/*
bool Board::overlap(Page page1, Page page2)
{
    // overlap boundary
    int left = (page1.get_x() < page2.get_x()) ? page1.get_x() : page2.get_x() ;
    int right = (page1.get_x()+page1.get_width() > page2.get_x()+page2.get_width()) ?
                 page1.get_x()+page1.get_width() : page2.get_x()+page2.get_width() ;
    int up = (page1.get_y() < page2.get_y()) ? page1.get_y() : page2.get_y() ;
    int down = (page1.get_y()+page1.get_height() > page2.get_y()+page2.get_height()) ?
                page1.get_y()+page1.get_height() : page2.get_y()+page2.get_height() ;

    if ((down-up < page1.get_height()+page2.get_height()-1) && (right-left < page1.get_width()+page2.get_width()-1))
    {
        return true ;
    }
    else
    {
        return false ;
    }
}
*/

void Board::insert_page(int x, int y, int width, int height, int id, int content) {
    Page page = Page(x,y,width,height,id,content) ;
    pages[p_index] = page ; // save page in log
    p_index += 1 ;

    int start = x + (this->width)*y ;
    for (int i=0; i<height, i++)
    {
        for (int j=0; j<width, j++)
        {
            int *spot = board[start + i*(this->width) + j] ;
            spot[highest(spot)+1] = id ; // append id to ptrptr
        }
    }
}

void Board::delete_page(int id) {
    
}

void Board::modify_content(int id, char content) { // remove and re-insert
   
}

void Board::modify_position(int id, int x, int y) {
     
}
